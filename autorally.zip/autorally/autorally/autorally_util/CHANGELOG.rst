^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package autorally_util
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.5 (2017-07-03)
------------------
* Small fixes in command priorities, c++11 support

0.2.4 (2017-02-14)
------------------
* Added new rule for the Arduino Micro in udev rules after it was found that uploading code using arduino IDE version 1.8 changes one of the parameters we were keying off of

0.2.3 (2016-09-20 11:06)
------------------------

0.2.2 (2016-09-20 11:05:39)
---------------------------

0.2.1 (2016-09-20 11:05:16)
---------------------------

0.2.0 (2016-09-20 11:04)
------------------------
