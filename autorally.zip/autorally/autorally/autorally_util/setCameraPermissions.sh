#! /bin/bash

sudo chmod -R 777 /dev/bus/usb/

exit 0
