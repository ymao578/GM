/*
* Software License Agreement (BSD License)
* Copyright (c) 2013, Georgia Institute of Technology
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this
* list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/**********************************************
 * @file L1control.h
 * @author Yuliang Gu <yuliang3@illinois.edu>
 * @date October 7, 2020
 * @copyright 2012 Georgia Institute of Technology
 * @brief L1 controller
 *
 ***********************************************/
#ifndef JUMP_CONTROL_H_
#define JUMP_CONTROL_H_

#include <map>
#include <ros/ros.h>
#include <ros/time.h>
#include <nodelet/nodelet.h>
#include <Eigen/Dense>
#include <tf/transform_listener.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/Point.h>
#include <std_msgs/Float64.h>

#include <autorally_msgs/chassisCommand.h>
#include <autorally_msgs/wheelSpeeds.h>
#include <autorally_core/RingBuffer.h>

#define PI 3.14159265358979323846264338

namespace autorally_control
{

  class L1control : public nodelet::Nodelet
  {
  public:
    L1control();
    ~L1control();
    void onInit();

  private:
    bool switch_flag = false;
    bool l1_flag = false;
    int heading_multiplier;
    float last_heading;
    float Ts = 0.02;
    float yaw;
    float steering_p = 0.5;
    float d_switch = 5000;
    float d_acc = 3500;
    float x_pos;

    /* state variables */
    float u; // control input (throttle between -1 and 1)

    float u_x;     // longitudinal velocity
    float u_x_hat; // longitudinal velocity predictor
    float u_x_ref = 15.0; // longitudinal velocity reference
    float u_x_refS = 3.8;

    float angular_vel;              // wheel velocity
    float angular_vel_hat;          // wheel velocity predictor
    float angular_vel_ref = 15.0; // wheel velocity reference
    float angular_vel_refS = 3.8;

    float f_hat_m;   // matched uncertainties
    float f_hat_um;  // unmathced uncertainites

    float filter_x1; // low pass filter state 1
    float filter_x2; // low pass filter state 2

    /* baseline controller parameters */
    float bl_fb1 = -0.5036;
    float bl_fb2 = -1.038;

    // float s_bl_fb1 = -0.0051;
    // float s_bl_fb2 = 0.009776;

    float s_bl_fb1 = 0.014;
    float s_bl_fb2 = -0.0451;

    /*Learned normal system */
    float a_11 = 0.2753;
    float a_12 = -0.4740;
    float a_21 = 1.1742;
    float a_22 = -1.3313;

    // float s_a_11 = -0.5389;
    // float s_a_12 = 0.4256;
    // float s_a_21 = -0.4220;
    // float s_a_22 = 0.2541;

    float s_a_11 = 0.2444;
    float s_a_12 = -0.5151;
    float s_a_21 = 17.0038;
    float s_a_22 = -17.0165;

    /* L1 controller parameters */
    float lpf_a = 0.99;
    float lpf_b = 0.01;

    // std_msgs::Float64 lastSpeedCommand;

    /* Subscribers and publishers */
    ros::Subscriber pose_sub;
    ros::Subscriber wheel_sub;
    ros::Subscriber ref_sub;
    ros::Publisher control_pub;
    // ros::Timer l1controlTimer;

    /* Callback functions */
    void poseCallback(const nav_msgs::OdometryConstPtr &msg);
    // void refSpeedCallback(const std_msgs::Float64ConstPtr &msg);
    void wheelSpeedCallback(const autorally_msgs::wheelSpeedsConstPtr &msg);

    /* publish control command */
    // void pubControl(const float &throttle) const;

    /* Controllers */
    void baseLineControl(float &u_bl);
    void s_baseLineControl(float &u_bl);

    void l1controlCommand(float &u_l1control);
    void s_l1controlCommand(float &u_l1control);

    /* Throttle mappings */
    autorally_core::RingBuffer<double> m_throttleMappings;
    void loadThrottleCalibration();

    float Clamp(float x, float min, float max);
  };

} // namespace autorally_control
#endif
