/*
* Software License Agreement (BSD License)
* Copyright (c) 2013, Georgia Institute of Technology
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice, this
* list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright notice,
* this list of conditions and the following disclaimer in the documentation
* and/or other materials provided with the distribution.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/**********************************************
 * @file L1control.h
 * @author Yuliang Gu <yuliang3@illinois.edu>
 * @date October 7, 2020
 * @copyright 2012 Georgia Institute of Technology
 * @brief L1 controller
 *
 ***********************************************/

#include <math.h>
#include <pluginlib/class_list_macros.h>

#include "L1control.h"

PLUGINLIB_EXPORT_CLASS(autorally_control::L1control, nodelet::Nodelet)

namespace autorally_control
{
    L1control::L1control() : heading_multiplier(0),
                             last_heading(0.0),
                             angular_vel_hat(0.0),
                             filter_x1(0.0),
                             filter_x2(0.0),
                             f_hat_m(0.0),
                             f_hat_um(0.0),
                             u_x_hat(0.0)
    {
    }

    L1control::~L1control() {}

    void L1control::onInit()
    {
        NODELET_INFO("L1 Adaptive Controller initialization");
        ros::NodeHandle nh = getNodeHandle();

        // lastSpeedCommand.data = 0;

        // loadThrottleCalibration();

        pose_sub = nh.subscribe("/ground_truth/state", 1, &L1control::poseCallback, this); // 100hz
        // ref_sub = nh.subscribe("L1control/speedCommand", 1, &L1control::refSpeedCallback, this);
        wheel_sub = nh.subscribe("wheelSpeeds", 1, &L1control::wheelSpeedCallback, this); // 50hz

        control_pub = nh.advertise<autorally_msgs::chassisCommand>("L1control/chassisCommand", 1); //50hz

        // l1controlTimer = nh.createTimer(ros::Rate(1), L1control::controlCallback, this)
    }

    // void L1control::refSpeedCallback(const std_msgs::Float64ConstPtr &msg)
    // {
    //     if (lastSpeedCommand.data != msg->data)
    //     {
    //         NODELET_INFO_STREAM("New speed Command :" << msg->data);
    //     }
    //     lastSpeedCommand = *msg;
    // }

    void L1control::wheelSpeedCallback(const autorally_msgs::wheelSpeedsConstPtr &msg)
    {
        // angular_vel = 0.5 * (msg->lfSpeed + msg->rfSpeed) / 0.095; // wheel radius 0.095
        angular_vel = 0.5 * (msg->lbSpeed + msg->rbSpeed);

        autorally_msgs::chassisCommandPtr command(new autorally_msgs::chassisCommand);
        command->header.stamp = ros::Time::now();
        command->sender = "L1control";
        command->steering = Clamp(steering_p * (yaw - PI / 2), -1.0, 1.0);
        // command->steering = -5.0;
        command->frontBrake = 0.0;

        float u_bl;
        float u_ad = 0;
        float s_u_bl;
        float s_u_ad = 0;

        if (x_pos <= d_acc)
        {
            baseLineControl(u_bl);
            // l1controlCommand(u_ad);
            u = u_bl - u_ad;
            NODELET_INFO_STREAM("normal u:  " << u);
            u = Clamp(u, -1.0, 1.0);
        }
        else if (x_pos > d_acc && x_pos <= d_switch)
        {
            u_x_ref = 1.0;
            angular_vel_ref = 1.0;

            baseLineControl(u_bl);
            // l1controlCommand(u_ad);
            u = u_bl - u_ad;
            NODELET_INFO_STREAM("slow down u:  " << u);
            u = Clamp(u, -1.0, 1.0);
        }
        else
        {
            if (switch_flag)
            {
                s_baseLineControl(s_u_bl);
                // s_l1controlCommand(s_u_ad);
                u = s_u_bl - s_u_ad;
                NODELET_INFO_STREAM("switch model u:  " << u);
                u = Clamp(u, -1.0, 1.0);
            }
            else
            {
                u_x_ref = 3.80;
                angular_vel_ref = 3.80;

                baseLineControl(u_bl);
                // l1controlCommand(u_ad);
                u = u_bl - u_ad;
                NODELET_INFO_STREAM("no l1 u:  " << u);
                u = Clamp(u, -1.0, 1.0);
            }
        }
        command->throttle = u;
        control_pub.publish(command);
    }

    void L1control::poseCallback(const nav_msgs::OdometryConstPtr &msg)
    {
        // x position
        x_pos = msg->pose.pose.position.y;

        //Quaternion
        float q0 = msg->pose.pose.orientation.w;
        float q1 = msg->pose.pose.orientation.x;
        float q2 = msg->pose.pose.orientation.y;
        float q3 = msg->pose.pose.orientation.z;

        // Yaw
        yaw = atan2(2 * q1 * q2 + 2 * q0 * q3, q1 * q1 + q0 * q0 - q3 * q3 - q2 * q2);

        // Don't allow heading to wrap around
        if (last_heading > 3.0 && yaw < -3.0)
        {
            heading_multiplier += 1;
        }
        else if (last_heading < -3.0 && yaw > 3.0)
        {
            heading_multiplier -= 1;
        }
        last_heading = yaw;
        yaw = yaw + heading_multiplier * 2 * PI;

        // Update x,y velocities (world frame)
        float x_vel = msg->twist.twist.linear.x;
        float y_vel = msg->twist.twist.linear.y;

        // Update longitudenal velocity (body frame)
        u_x = cos(yaw) * x_vel + sin(yaw) * y_vel;
        // NODELET_INFO_STREAM("yaw:" << yaw);
    }

    void L1control::baseLineControl(float &u_bl)
    {
        // error between the current states and desired states
        float angular_vel_err = angular_vel - angular_vel_ref;
        float vel_err = u_x - u_x_ref;

        u_bl = bl_fb1 * angular_vel_err + bl_fb2 * vel_err - a_11 * angular_vel_ref - a_12 * u_x_ref;
    }

    void L1control::s_baseLineControl(float &s_u_bl)
    {
        // error between the current states and desired states
        float angular_vel_err = angular_vel - angular_vel_refS;
        float vel_err = u_x - u_x_refS;

        s_u_bl = s_bl_fb1 * angular_vel_err + s_bl_fb2 * vel_err - s_a_11 * angular_vel_refS - s_a_12 * u_x_refS;
    }

    void L1control::l1controlCommand(float &u_l1control)
    {
        // two cacade discrete low pass filter with bandwidth 5 rad/s
        filter_x1 = lpf_a * filter_x1 + lpf_b * f_hat_m;
        filter_x2 = lpf_a * filter_x2 + lpf_b * f_hat_um;

        // Piecewise constant adaptive law
        f_hat_m = -49.76 * (angular_vel_hat - angular_vel);
        f_hat_um = -49.48 * (u_x_hat - u_x);

        // Update state predictor
        angular_vel_hat += (a_11 * angular_vel + a_12 * u_x + u + f_hat_m - bl_fb1 * (angular_vel_hat - angular_vel)) * Ts;
        u_x_hat += (a_21 * angular_vel + a_22 * u_x + f_hat_um - bl_fb2 * (u_x_hat - u_x)) * Ts;

        // L1 control
        // u_l1control = Clamp(filter_x1,-1.0,1.0);
        u_l1control = filter_x1;
    }

    void L1control::s_l1controlCommand(float &s_u_l1control)
    {
        // two cacade discrete low pass filter with bandwidth 5 rad/s
        filter_x1 = lpf_a * filter_x1 + lpf_b * f_hat_m;
        filter_x2 = lpf_a * filter_x2 + lpf_b * f_hat_um;

        // Piecewise constant adaptive law
        f_hat_m = -49.76 * (angular_vel_hat - angular_vel);
        f_hat_um = -49.48 * (u_x_hat - u_x);

        // Update state predictor
        angular_vel_hat += (s_a_11 * angular_vel + s_a_12 * u_x + u + f_hat_m - s_bl_fb1 * (angular_vel_hat - angular_vel)) * Ts;
        u_x_hat += (s_a_21 * angular_vel + s_a_22 * u_x + f_hat_um - s_bl_fb2 * (u_x_hat - u_x)) * Ts;

        // L1 control
        // u_l1control = Clamp(filter_x1,-1.0,1.0);
        s_u_l1control = filter_x1;
    }

    void L1control::loadThrottleCalibration()
    {
        NODELET_INFO("Loading calibration");
        ros::NodeHandle nhPvt = getPrivateNodeHandle();
        XmlRpc::XmlRpcValue v;
        nhPvt.param("throttleCalibration", v, v);
        std::map<std::string, XmlRpc::XmlRpcValue>::iterator mapIt;
        for (mapIt = v.begin(); mapIt != v.end(); mapIt++)
        {
            if (mapIt->second.getType() == XmlRpc::XmlRpcValue::TypeDouble)
            {
                std::pair<double, double> toAdd(std::pair<double, double>(
                    boost::lexical_cast<double>(mapIt->first),
                    static_cast<double>(mapIt->second)));
                NODELET_INFO_STREAM("ConstantSpeedController added to add mapping " << toAdd.first << ":" << toAdd.second);
                if (!m_throttleMappings.update(toAdd))
                {
                    NODELET_ERROR_STREAM("ConstantSpeedController Failed to add mapping " << toAdd.first << ":" << toAdd.second);
                }
            }
            else
            {
                NODELET_ERROR("ConstantSpeedController: XmlRpc throttle calibration formatted incorrectly");
            }
        }
        NODELET_INFO_STREAM("ConstantSpeedController: Loaded " << m_throttleMappings.size() << " throttle mappings");
    }

    float L1control::Clamp(float x, float min, float max)
    {
        if (x < min)
            x = min;
        if (x > max)
            x = max;
        return x;
    }

} // namespace autorally_control