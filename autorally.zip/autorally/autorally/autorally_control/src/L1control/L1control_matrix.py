# a python script that calculates L1 parameters
import numpy as np

alpha = 10
Ts = 1/50

# As = -alpha * np.eye(2, dtype=float)
As = np.array([[-10,0],[0,-10]])

def cal_adaptation():
    sai = np.linalg.inv(As)*(np.exp(As*Ts)-np.eye(2))
    final = -np.linalg.inv(sai)*np.exp(As*Ts)
    print(final)

def cal_lpf():
    return 0

# cal_adaptation()

B = np.array([[0.1,0.1],[0,0]])
F = np.array([[13.5979,-35.3879],[-14.1122,36.3655]])
print(np.matmul(B,F))
